# WeChat_PublicAccountPay
微信公众号支付
本代码为微信公众号支付的代码，另外，公众号的一些参数我已经删掉，如果需要下载测试的话，请记得在WxLib/lib/config.cs里面添加相关的参数。
